import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Calculadora', url: '/calculadora', icon: 'calculator' },
    { title: 'CelsiusFahrenheit', url: '/celsius-fahrenheit', icon: 'thermometer' },
    { title: 'Convertidor', url: '/convertidor', icon: 'card' },
    { title: 'IMC', url: '/imc', icon: 'body' },
  ];
  public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
  constructor() {}
}
